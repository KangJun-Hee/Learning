package com.myspring.test06.board;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class BoardController {

	@Autowired
	BoardDAO dao;
	
	@ModelAttribute("cp")
	public String getContextPath(HttpServletRequest request) {
		return request.getContextPath();
	}
	
	@RequestMapping(value = "/board/boardList")
	public String boardList(HttpServletRequest request, Model model) {
		System.out.println("==== boardList() ====");
		
		int pageSize = 3;
		
		int currentPage = 1;
		if(request.getParameter("pageNum") != null) {
			currentPage = Integer.parseInt(request.getParameter("pageNum"));	
		}
		
		int count = dao.getAllCount();
			
		int startRow = (currentPage - 1) * pageSize;
	
		ArrayList<Board> boardList = dao.getAllBoard(startRow, pageSize);
		
		int number = count - (currentPage - 1) * pageSize;	
		
		int clickablePageCount = 5;
		int pageCount = count / pageSize + (count % pageSize == 0 ? 0 : 1);
		
		int startPage = 0;
		if(currentPage % clickablePageCount != 0) {
			startPage = (currentPage / clickablePageCount) * clickablePageCount + 1;
		}else {
			startPage = (currentPage / clickablePageCount - 1) * clickablePageCount + 1;
		}
		
		int endPage = startPage + clickablePageCount - 1;
		if(endPage > pageCount) endPage = pageCount;
		
		model.addAttribute("boardList", boardList);
		model.addAttribute("number", number);
		model.addAttribute("count", count);
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("pageSize", pageSize);
		
		model.addAttribute("clickablePageCount", clickablePageCount);
		model.addAttribute("pageCount", pageCount);
		model.addAttribute("startPage", startPage);
		model.addAttribute("endPage", endPage);

		return "board/boardList";
	}
	
	@RequestMapping(value = "/board/boardInfo")
	public String boardInfo(HttpServletRequest request, Model model) {
		System.out.println("==== boardInfo() ====");
		
		int num = Integer.parseInt(request.getParameter("num"));
		
		Board bean = dao.getOneBoard(num);
		
		model.addAttribute("bean", bean);
		
		return "board/boardInfo";
	}
	
	@RequestMapping(value = "/board/boardWriteForm")
	public String boardWriteForm() {
		System.out.println("==== boardWriteForm() ====");
		
		return "board/boardWriteForm";
	}
	
	@RequestMapping(value = "/board/boardWritePro", method = RequestMethod.POST)
	public String boardWritePro(HttpServletRequest request, Model model, Board bean) {
		System.out.println("==== boardWritePro() ====");
		
//		Board bean = new Board();
//		bean.setWriter(request.getParameter("writer"));
//		bean.setSubject(request.getParameter("subject"));
//		bean.setEmail(request.getParameter("email"));
//		bean.setPassword(request.getParameter("password"));
//		bean.setContent(request.getParameter("content"));	
		
		dao.insertBoard(bean);
		
		model.addAttribute("bean", bean);
		
		return "redirect:/board/boardList";
	}

	@RequestMapping(value = "/board/reWriteForm")
	public String reWriteForm(HttpServletRequest request, Model model) {
		System.out.println("==== reWriteForm() ====");
		
		int num = Integer.parseInt(request.getParameter("num"));
		Board bean = dao.getOneBoard(num);
		
		int ref = bean.getRef();
		int re_step = bean.getRe_step();
		int re_level = bean.getRe_level();
		
		
		model.addAttribute("ref", ref);
		model.addAttribute("re_step",re_step);
		model.addAttribute("re_level", re_level);
		
		return "board/reWriteForm";
	}
	
	@RequestMapping(value = "/board/reWritePro", method = RequestMethod.POST)
	public String reWritePro(HttpServletRequest request, Model model, Board bean) {
		System.out.println("==== reWritePro() ====");
		
//		Board bean = new Board();
//		bean.setWriter(request.getParameter("writer"));
//		bean.setSubject(request.getParameter("subject"));
//		bean.setEmail(request.getParameter("email"));
//		bean.setPassword(request.getParameter("password"));
//		bean.setContent(request.getParameter("content"));
//
//		bean.setRef(Integer.parseInt(request.getParameter("ref")));
//		bean.setRe_step(Integer.parseInt(request.getParameter("re_step")));
//		bean.setRe_level(Integer.parseInt(request.getParameter("re_level")));
		
		dao.reWriteBoard(bean);
		
		return "redirect:/board/boardList";
	}
	
}














