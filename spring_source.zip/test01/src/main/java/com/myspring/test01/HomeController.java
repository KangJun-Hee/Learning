package com.myspring.test01;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		
		System.out.println("home() 메서드 실행");
		
		// /WEB-INF/views/home.jsp
		// home이라고만 적어도 위의 경로로 맵핑되어 실행된다.
		return "home";
	}
	
}
