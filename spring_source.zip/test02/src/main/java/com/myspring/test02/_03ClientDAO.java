package com.myspring.test02;

import java.util.ArrayList;
import java.util.HashMap;

public class _03ClientDAO {
	private String companyName;
	
	private ArrayList<String> clientList1;
	private HashMap<String, String> clientMap1;
	private HashMap<String, _03Client> clientMap2;
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public ArrayList<String> getClientList1() {
		return clientList1;
	}
	public void setClientList1(ArrayList<String> clientList1) {
		this.clientList1 = clientList1;
	}
	public HashMap<String, String> getClientMap1() {
		return clientMap1;
	}
	public void setClientMap1(HashMap<String, String> clientMap1) {
		this.clientMap1 = clientMap1;
	}
	public HashMap<String, _03Client> getClientMap2() {
		return clientMap2;
	}
	public void setClientMap2(HashMap<String, _03Client> clientMap2) {
		this.clientMap2 = clientMap2;
	}
	
}
