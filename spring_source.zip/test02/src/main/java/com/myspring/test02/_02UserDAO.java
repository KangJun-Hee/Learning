package com.myspring.test02;

public class _02UserDAO {
	private _02User user;
	
	public _02UserDAO(_02User user) {
		this.user = user;
	}
	
	public void print() {
		user.print();
	}
}
