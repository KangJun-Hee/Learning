package com.myspring.test02;

public class _01Member {
	int a = 0;
	
	public void add(int val) {
		a = a + val;
	}
	
	public void print() {
		System.out.println(a);
	}
}
