package com.myspring.test02;

public class _02User {

	public void print() {
		System.out.println("User");
	}
}
