package com.ap4j.bma.service.customerCenter;

import com.ap4j.bma.model.entity.customerCenter.FAQEntity;
import com.ap4j.bma.model.repository.FAQRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FAQService {
    @Autowired
    private FAQRepository faqRepository;

    public List<FAQEntity> getAllFAQ() {

        return faqRepository.findAll();
    }

    public FAQEntity faqView(Integer id) {
        return faqRepository.findById(id).get();
    }

    public Page<FAQEntity> getFAQPage(Pageable pageable) {
        return faqRepository.findAll(pageable);
    }

    public Page<FAQEntity> findByCategory(String category, Pageable pageable) {
        return faqRepository.findByCategory(category, pageable);
    }
}
