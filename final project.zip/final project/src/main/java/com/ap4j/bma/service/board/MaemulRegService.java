package com.ap4j.bma.service.board;

public class MaemulRegService {
}
