//package com.ap4j.bma.model.entity.details;
//
//
//import lombok.*;
//import org.springframework.stereotype.Component;
//
//@Component
//@Getter
//@Setter
//@AllArgsConstructor
//@NoArgsConstructor
//@ToString
//public class DetailsDTO {
//
//
//}
