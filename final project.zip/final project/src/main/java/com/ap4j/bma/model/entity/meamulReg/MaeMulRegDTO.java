//package com.ap4j.bma.model.entity.meamulReg;
//
//
//import lombok.*;
//import org.springframework.stereotype.Component;
//
//@Component
//@Getter
//@Setter
//@AllArgsConstructor
//@NoArgsConstructor
//@ToString
//public class MaeMulRegDTO {
//
//
//}
