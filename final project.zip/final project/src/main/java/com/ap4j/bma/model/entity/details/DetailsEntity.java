package com.ap4j.bma.model.entity.details;

public class DetailsEntity {
}
