package com.ap4j.bma.service.admin;

public interface AdminService {

	void addSomething(String something);
}
