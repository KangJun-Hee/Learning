package com.ap4j.bma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BmaApplication {


	public static void main(String[] args) {
		SpringApplication.run(BmaApplication.class, args);
	}

}
