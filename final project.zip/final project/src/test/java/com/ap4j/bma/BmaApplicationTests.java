package com.ap4j.bma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
