//function openModal(){
//        document.getElementById('aSaveBtn').addEventListener('click', function() {
//            // 여기서 로그인 여부 확인 및 처리
//            var isLoggedIn = true;  // 로그인 여부에 따라 true 또는 false 설정
//
//            // 동적으로 모달 내용 변경
//            var dynamicModalBody = document.getElementById('dynamicModalBody');
//
//            if (isLoggedIn) {
//                dynamicModalBody.innerHTML = '<p>로그인되었습니다.</p>';
//            } else {
//                dynamicModalBody.innerHTML = '<p>로그인이 필요합니다.</p>';
//            }
//        });
//
//}