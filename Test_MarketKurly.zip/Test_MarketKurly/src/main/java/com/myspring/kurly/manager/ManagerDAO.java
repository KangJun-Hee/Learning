package com.myspring.kurly.manager;

public class ManagerDAO {

}
