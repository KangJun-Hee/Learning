package com.myspring.kurly.item;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ItemController {
	
	//브라우저 주소가 /create일때 실행되는 자바 컨트롤러 메소드
	@RequestMapping(value="/view/05_addNewItem")
	public String addNewItem() {
		return "views/05_addNewItem";
	}
	
	
	@RequestMapping(value="/07_updateItem", method=RequestMethod.GET)
	public ModelAndView update(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView("update");
		
		int bno = Integer.parseInt(request.getParameter("bno"));
		ItemDTO dto = itemMapper.getItem();
		mv.addObject("dto",dto);
		
		return "views/07_updateItem"/
	}
	
	
	
}