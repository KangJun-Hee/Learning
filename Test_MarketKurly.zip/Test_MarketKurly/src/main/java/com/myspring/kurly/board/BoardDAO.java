package com.myspring.kurly.board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;

import com.kh.springmember.Member;

public class BoardDAO {
	
	public String update(BoardDTO dto) {
		sqlSession.update("",);
		return "";
	}
	public void delete(int bno	) {
		sqlSession.delete("",);
	}
	
	@Autowired
	DataSource dataSource;// DB를 연결해준다, 커넥션정보 담고있음, 빈으로 등록해 인자넘김

	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;

	public void finallyClose() {
		try {
			if (pstmt != null) {
				pstmt.close();
			}
			if (conn != null) {
				pstmt.close();
			}
			if (rs != null) {
				pstmt.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void customer() {
		// DB연결 getConnect()
		try {
			conn = dataSource.getConnection();

			String sql = "INSERT INTO customer()VALUES(?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.get());
			pstmt.setString(2, member.get());
			pstmt.setString(3, member.get());
			// 명령문컴파일
			// 실제데이터들 ? 채우기
			// 쿼리 날리기!
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			finallyClose();
		}
	}

	public int check (   ) {
		int check = -1; // 마이너스1은 의미없는숫자

		try {
			conn = dataSource.getConnection();
			// sql명령문 작성후 id,pw넘기기
			String sql = "select * from   where id = ? and pw = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,  .getId());
			pstmt.setString(2,  .getPw());

			// executeQuery()
			rs = pstmt.executeQuery();

		} catch (Exception e) {
		} finally {
			finallyClose();
		}

		return check;
	}
}

