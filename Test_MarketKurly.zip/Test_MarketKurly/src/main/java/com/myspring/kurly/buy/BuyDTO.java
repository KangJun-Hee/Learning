package com.myspring.kurly.buy;

public class BuyDTO {

}
