package com.myspring.kurly.cart;

public class CartDTO {

}
