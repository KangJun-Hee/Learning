package com.myspring.kurly.item;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;

import com.kh.springmember.Member;

public class ItemDAO {
	@Autowired
	DataSource dataSource;// DB를 연결해준다, 커넥션정보 담고있음, 빈으로 등록해 인자넘김

	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;

	public void finallyClose() {
		try {
			if (pstmt != null) {
				pstmt.close();
			}
			if (conn != null) {
				pstmt.close();
			}
			if (rs != null) {
				pstmt.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void update (   ) {
		try {
			conn = dataSource.getConnection();
			// sql명령문 작성후 id,pw넘기기
			String sql = "update   set  =?,  =?, where  =?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,  .getPw());
			pstmt.setString(2,  .getEmail());
			pstmt.setString(3,  .getId());

			pstmt.executeUpdate();
			
		} catch (Exception e) {
		} finally {
			finallyClose();
		}
	}
}
