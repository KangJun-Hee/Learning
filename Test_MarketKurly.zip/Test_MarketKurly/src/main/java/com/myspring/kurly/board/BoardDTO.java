package com.myspring.kurly.board;

public class BoardDTO {

}
