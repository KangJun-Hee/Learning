package com.myspring.kurly.customer;

public class CustomerDTO {

}
