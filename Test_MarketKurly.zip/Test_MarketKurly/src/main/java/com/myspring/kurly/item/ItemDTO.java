package com.myspring.kurly.item;

public class ItemDTO {

}
