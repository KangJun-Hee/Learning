package com.sbs.kurly.cart;

public class CartDAO {

}
