package com.sbs.kurly.buy;

public class BuyDAO {

}
